const KEY = "harbor-hotel-v1";
const TABS = [["home","Home"],["dashboard","Dashboard"],["bookings","Bookings"],["rooms","Rooms"],["guests","Guests"]];
const LIVE = ["reserved","checked_in"];
let S, filter = "";

/* ---------- storage (data stays in this browser) ---------- */
function load(){
  try { S = JSON.parse(localStorage.getItem(KEY)); } catch(e) {}
  if (!S) S = { n: 7, guests: [], bookings: [],
    rooms: [["101","Standard",2500,2],["102","Standard",2500,2],["201","Deluxe",4200,3],
            ["202","Deluxe",4200,3],["301","Suite",8500,4],["302","Family",6000,5]]
      .map((r,i) => ({ id:i+1, number:r[0], type:r[1], rate:r[2], cap:r[3], maint:false })) };
}
function save(){ try { localStorage.setItem(KEY, JSON.stringify(S)); } catch(e) {} }

/* ---------- helpers ---------- */
const today = () => new Date(Date.now() - new Date().getTimezoneOffset()*6e4).toISOString().slice(0,10);
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const money = v => "₹" + Number(v).toLocaleString("en-IN");
const label = s => s.replace("_"," ").replace(/^./, c => c.toUpperCase());
const room = id => S.rooms.find(r => r.id === id);
const guest = id => S.guests.find(g => g.id === id);
function flash(msg, type=""){ document.getElementById("flash").innerHTML = `<div class="flash ${type}" role="status">${esc(msg)}</div>`; }
function isFree(roomId, ci, co){
  return !S.bookings.some(b => b.roomId === roomId && LIVE.includes(b.status) && b.ci < co && b.co > ci);
}
function actions(b){
  if (b.status === "reserved") return `<div class="acts"><button class="btn sm" onclick="act(${b.id},'checked_in')">Check in</button>
    <button class="btn sm danger" onclick="act(${b.id},'cancelled')">Cancel</button></div>`;
  if (b.status === "checked_in") return `<div class="acts"><button class="btn sm" onclick="act(${b.id},'checked_out')">Check out</button></div>`;
  return "";
}

/* ---------- views ---------- */
function home(){
  const busy = new Set(S.bookings.filter(b => b.status === "checked_in").map(b => b.roomId));
  const open = S.rooms.filter(r => !r.maint);
  const free = open.filter(r => !busy.has(r.id)).length;
  const types = {};
  open.forEach(r => { const t = types[r.type] ||= { n: 0, from: r.rate, cap: r.cap };
    t.n++; t.from = Math.min(t.from, r.rate); t.cap = Math.max(t.cap, r.cap); });
  const icon = { Standard: "🛏️", Deluxe: "🌅", Suite: "👑", Family: "👨‍👩‍👧" };
  const cards = Object.entries(types).map(([name, t]) => `<div class="rt rt-${icon[name] ? name : "Other"}">
    <span class="ic">${icon[name] || "🏨"}</span><h3>${esc(name)}</h3><span>Sleeps up to ${t.cap} · ${t.n} room${t.n > 1 ? "s" : ""}</span>
    <span>From</span><b>${money(t.from)}<small> / night</small></b></div>`).join("");
  const chips = ["📶 Free Wi-Fi","🏊 Rooftop pool","🍽️ Restaurant","🛎️ 24-hour reception","🚗 Free parking"]
    .map(c => `<span class="chip">${c}</span>`).join("");
  return `<section class="banner"><div><h1>Welcome to Harbor Hotel</h1>
    <p>Sea-view rooms, a rooftop pool and a front desk that never sleeps. ${free} room${free === 1 ? " is" : "s are"} free tonight.</p>
    <a class="btn" href="#new">Book a room</a><a class="btn alt" href="#dashboard">Open front desk</a></div></section>
    <div class="chips">${chips}</div><h2>Our rooms</h2><div class="rtypes">${cards}</div>`;
}

function dashboard(){
  const t = today(), total = S.rooms.length;
  const occ = new Set(S.bookings.filter(b => b.status === "checked_in").map(b => b.roomId)).size;
  const maint = S.rooms.filter(r => r.maint).length;
  const rev = S.bookings.filter(b => ["checked_in","checked_out"].includes(b.status)).reduce((a,b) => a + b.total, 0);
  const pct = total ? Math.round(100*occ/total) : 0;
  const arr = S.bookings.filter(b => b.status === "reserved" && b.ci <= t);
  const dep = S.bookings.filter(b => b.status === "checked_in" && b.co <= t);
  const table = (list, h, k) => list.length ? `<table class="cards"><thead><tr><th>Guest</th><th>Room</th><th>${h}</th><th></th></tr></thead><tbody>
    ${list.map(b => `<tr><td data-l="Guest">${esc(guest(b.guestId).name)}</td><td data-l="Room">${esc(room(b.roomId).number)}</td>
    <td data-l="${h}">${b[k]}</td><td class="acts-cell">${actions(b)}</td></tr>`).join("")}</tbody></table>` : `<p class="empty">Nothing waiting.</p>`;
  return `<div class="head"><div><h1>Front desk</h1><p class="muted">${t}</p></div><a class="btn" href="#new">New booking</a></div>
  <div class="grid"><div class="stat hero"><span class="muted">Occupancy today</span><b>${pct}%</b><div class="meter"><i style="width:${pct}%"></i></div></div>
  <div class="stat"><span class="muted">Occupied</span><b>${occ}</b></div>
  <div class="stat"><span class="muted">Available</span><b>${total-occ-maint}</b></div>
  <div class="stat"><span class="muted">Under maintenance</span><b>${maint}</b></div>
  <div class="stat"><span class="muted">Revenue from stays</span><b>${money(rev)}</b></div></div>
  <div class="cols"><section class="panel"><h2>Arrivals to check in</h2>${table(arr,"Arrives","ci")}</section>
  <section class="panel"><h2>Departures to check out</h2>${table(dep,"Leaves","co")}</section></div>`;
}

function rooms(){
  const occ = new Set(S.bookings.filter(b => b.status === "checked_in").map(b => b.roomId));
  const rows = [...S.rooms].sort((a,b) => a.number.localeCompare(b.number, undefined, {numeric:true})).map(r => `<tr>
    <td data-l="Room"><b>${esc(r.number)}</b></td><td data-l="Type">${r.type}</td><td data-l="Rate">${money(r.rate)}</td><td data-l="Sleeps">${r.cap}</td>
    <td data-l="Status">${r.maint ? '<span class="tag maint">Maintenance</span>' : occ.has(r.id) ? '<span class="tag occupied">Occupied</span>' : '<span class="tag free">Available</span>'}</td>
    <td class="acts-cell"><div class="acts"><button class="btn ghost sm" onclick="toggleMaint(${r.id})">${r.maint ? "Return to service" : "Mark maintenance"}</button>
    <button class="btn danger sm" onclick="delRoom(${r.id})">Delete</button></div></td></tr>`).join("");
  return `<div class="head"><div><h1>Rooms</h1><p class="muted">${S.rooms.length} rooms in the hotel</p></div></div>
  <section class="panel"><h2>Add a room</h2><form class="stack" onsubmit="return addRoom(event)">
  <label>Room number<input name="number" required></label>
  <label>Type<select name="type"><option>Standard</option><option>Deluxe</option><option>Suite</option><option>Family</option></select></label>
  <label>Rate per night (₹)<input name="rate" type="number" min="0" step="50" required></label>
  <label>Guests<input name="cap" type="number" min="1" max="10" value="2" required></label>
  <label>&nbsp;<button class="btn">Add room</button></label></form></section>
  <section class="panel"><table class="cards"><thead><tr><th>Room</th><th>Type</th><th>Rate</th><th>Sleeps</th><th>Status</th><th></th></tr></thead><tbody>${rows}</tbody></table></section>`;
}

function bookings(){
  const list = S.bookings.filter(b => !filter || b.status === filter).sort((a,b) => b.ci.localeCompare(a.ci));
  const tabs = [["","All"],["reserved","Reserved"],["checked_in","Checked in"],["checked_out","Checked out"],["cancelled","Cancelled"]]
    .map(([k,n]) => `<button class="btn sm ${filter===k ? "" : "ghost"}" onclick="setFilter('${k}')">${n}</button>`).join("");
  const rows = list.map(b => `<tr><td data-l="#">${b.id}</td><td data-l="Guest">${esc(guest(b.guestId).name)}</td>
    <td data-l="Room">${esc(room(b.roomId).number)} (${room(b.roomId).type})</td><td data-l="Stay">${b.ci} to ${b.co}</td>
    <td data-l="Total">${money(b.total)}</td><td data-l="Status"><span class="tag ${b.status}">${label(b.status)}</span></td>
    <td class="acts-cell">${actions(b)}</td></tr>`).join("");
  return `<div class="head"><div><h1>Bookings</h1><p class="muted">${list.length} shown</p></div><a class="btn" href="#new">New booking</a></div>
  <div class="filters">${tabs}</div><section class="panel">${list.length ? `<table class="cards"><thead><tr><th>#</th><th>Guest</th><th>Room</th><th>Stay</th><th>Total</th><th>Status</th><th></th></tr></thead><tbody>${rows}</tbody></table>`
  : '<p class="empty">No bookings here yet. Create one with New booking.</p>'}</section>`;
}

function newBooking(){
  const t = today();
  const opts = S.rooms.filter(r => !r.maint).map(r => `<option value="${r.id}">${esc(r.number)} · ${r.type} · ${money(r.rate)}/night</option>`).join("");
  return `<div class="head"><div><h1>New booking</h1><p class="muted">Total is calculated from nights and room rate.</p></div></div>
  <section class="panel"><form class="stack" onsubmit="return addBooking(event)">
  <label>Guest name<input name="name" required></label><label>Phone<input name="phone" type="tel"></label>
  <label>Email<input name="email" type="email"></label><label>Room<select name="room" required>${opts}</select></label>
  <label>Check-in<input type="date" name="ci" min="${t}" value="${t}" required></label>
  <label>Check-out<input type="date" name="co" min="${t}" required></label>
  <label>&nbsp;<button class="btn">Create booking</button></label></form></section>`;
}

function guests(){
  const rows = [...S.guests].sort((a,b) => a.name.localeCompare(b.name)).map(g => {
    const mine = S.bookings.filter(b => b.guestId === g.id && b.status !== "cancelled");
    return `<tr><td data-l="Name">${esc(g.name)}</td><td data-l="Phone">${esc(g.phone) || "-"}</td><td data-l="Email">${esc(g.email) || "-"}</td>
    <td data-l="Stays">${mine.length}</td><td data-l="Spent">${money(mine.reduce((a,b) => a + b.total, 0))}</td></tr>`; }).join("");
  return `<div class="head"><div><h1>Guests</h1><p class="muted">${S.guests.length} on record</p></div></div><section class="panel">
  ${S.guests.length ? `<table class="cards"><thead><tr><th>Name</th><th>Phone</th><th>Email</th><th>Stays</th><th>Spent</th></tr></thead><tbody>${rows}</tbody></table>`
  : "<p class='empty'>No guests yet. They're added when you create a booking.</p>"}</section>`;
}

/* ---------- actions ---------- */
function addRoom(e){
  e.preventDefault();
  const f = new FormData(e.target), number = f.get("number").trim();
  if (S.rooms.some(r => r.number === number)) { flash("That room number already exists.", "error"); return false; }
  S.rooms.push({ id: S.n++, number, type: f.get("type"), rate: +f.get("rate"), cap: +f.get("cap"), maint: false });
  save(); flash("Room added."); render(); return false;
}
function toggleMaint(id){ const r = room(id); r.maint = !r.maint; save(); render(); }
function delRoom(id){
  if (S.bookings.some(b => b.roomId === id)) return flash("This room has bookings, so it can't be deleted. Mark it under maintenance instead.", "error");
  if (!confirm("Delete this room?")) return;
  S.rooms = S.rooms.filter(r => r.id !== id); save(); flash("Room deleted."); render();
}
function addBooking(e){
  e.preventDefault();
  const f = Object.fromEntries(new FormData(e.target)), r = room(+f.room), name = f.name.trim();
  let err = "";
  if (f.co <= f.ci) err = "Check-out must be after check-in.";
  else if (f.ci < today()) err = "Check-in can't be in the past.";
  else if (!r) err = "Choose a room.";
  else if (!isFree(r.id, f.ci, f.co)) err = `Room ${r.number} is already booked for those dates. Pick other dates or another room.`;
  if (err) { flash(err, "error"); return false; }
  const email = f.email.trim().toLowerCase();
  let g = email && S.guests.find(x => x.email === email);
  if (!g) { g = { id: S.n++, name, phone: f.phone.trim(), email }; S.guests.push(g); }
  const nights = (new Date(f.co) - new Date(f.ci)) / 864e5;
  S.bookings.push({ id: S.n++, guestId: g.id, roomId: r.id, ci: f.ci, co: f.co, status: "reserved", total: nights * r.rate });
  save(); flash(`Booking created for ${name} in room ${r.number}.`); location.hash = "#bookings"; return false;
}
function act(id, status){ S.bookings.find(b => b.id === id).status = status; save(); flash("Booking updated."); render(); }
function setFilter(k){ filter = k; render(); }

/* ---------- router ---------- */
function render(){
  const page = location.hash.slice(1) || "home";
  const views = { home, dashboard, bookings, rooms, guests, new: newBooking };
  document.getElementById("view").innerHTML = (views[page] || dashboard)();
  document.getElementById("nav").innerHTML = TABS.map(([k,n]) =>
    `<a href="#${k}" class="${page === k || (page === "new" && k === "bookings") ? "on" : ""}">${n}</a>`).join("");
}
window.addEventListener("hashchange", () => { document.getElementById("flash").innerHTML = ""; render(); });
load(); render();
